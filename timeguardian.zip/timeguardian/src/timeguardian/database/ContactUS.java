package timeguardian.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import com.time.DBUtil.DBConnection;

public class ContactUS {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	String sql;
	
	public int insertQuery(Vector<String> con_vect) throws ClassNotFoundException, SQLException {
		con = DBConnection.getCon();
		sql="insert into contact_us (con_name,con_email,con_mobile,con_msg) values(?,?,?,?)";
		pst = con.prepareStatement(sql);
		Object con_arr[] = con_vect.toArray();
		int i=1;
		for(Object itr : con_arr) {
			pst.setString(i, (String)itr);
			i++;
		}
		return pst.executeUpdate();
	}
//	public static void main(String[] args) {
//		
//	}
}
