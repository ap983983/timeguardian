package com.timeguardian.faculty;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Y1")
public class Y1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public Y1() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String options="";
		int token = Integer.parseInt(request.getParameter("token"));
		try {
			com.timeguardian.dao.Y1 y1=new com.timeguardian.dao.Y1();
			switch(token) {
			case 1:
				ArrayList<String> course = y1.courseList();
				Iterator<String>  itr=course.iterator();
				while(itr.hasNext()) {
					String c=itr.next();
					options+="<option value="+c+">"+c+"</option><br>";
				}
				out.print(options);
				break;
			case 2:
				break;
			case 3:
				break;
			case 4:
				break;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
