package com.timeguardian.faculty;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.timeguardian.dao.FacultyDao;

/**
 * Servlet implementation class AssignTaskFaculty
 */
@WebServlet("/AssignTaskFaculty")
public class AssignTaskFaculty extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AssignTaskFaculty() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String msgsub=request.getParameter("subject");
		String msginfo=request.getParameter("editor_content");
		String sub_id=request.getParameter("sub_id");
		String[] student_id=request.getParameterValues("stuid");
		String facid=request.getParameter("fac_id");
		try {
			FacultyDao facultyDao=new FacultyDao();
			facultyDao.assignTaskHod(facid, msgsub, msginfo, student_id, sub_id);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
