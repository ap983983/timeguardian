package com.timeguardian.student;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.time.DBUtil.DBConnection;
import com.timeguardian.dao.StudentDao;

@WebServlet("/Upload")
public class Upload extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String profile_name;
    Connection con;
    PreparedStatement pst;
    public Upload() throws ClassNotFoundException, SQLException {
        super();
        con = DBConnection.getCon();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();	
		try {
			ServletFileUpload sf= new ServletFileUpload(new DiskFileItemFactory());
			List<FileItem> list=sf.parseRequest(request);
			for(FileItem f : list) {
				if(f.isFormField()) {
					profile_name = f.getString();
				}else {
					new StudentDao().updateProfile(profile_name,f.getName());
					f.write(new File("/home/akash/eclipse-workspace/timeguardian/WebContent/student/images/"+f.getName()));
				}
				
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
