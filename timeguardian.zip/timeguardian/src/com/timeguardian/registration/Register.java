package com.timeguardian.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.timeguardian.beans.FacultyBean;
import com.timeguardian.beans.HodBean;
import com.timeguardian.beans.StudentBean;
import com.timeguardian.dao.FacultyDao;
import com.timeguardian.dao.HodDao;
import com.timeguardian.dao.StudentDao;

@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }
    int result = 500;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		response.setContentType("text/plain");
		PrintWriter out = response.getWriter();
		String fname = request.getParameter("fname");
		String profession = request.getParameter("prof");
		String lname = request.getParameter("lname");
		String mobile = request.getParameter("mobile");
		String email = request.getParameter("email");
	
		/*----------------------*
		 * Student Registration	*
		 *----------------------*/
		
		if(profession.equalsIgnoreCase("s")){
			
			String stu_id=request.getParameter("rollno");
			String course = request.getParameter("course");
			String branch = request.getParameter("branch");
			String semester =request.getParameter("sem");
			String section = request.getParameter("section");
			StudentBean stu=new StudentBean(stu_id, fname, lname, mobile, email, course, branch, semester, section);
			try {
				StudentDao stu1=new StudentDao();
				if(stu1.isUserExists(stu_id))
					result = -1;
				else if(stu1.isEmailExists(email))
					result = -2;
				else if(stu1.isMobileExists(mobile))
					result = -3;
				else {
					int otp = new Random().nextInt(10000);
					String msg = "Welcome to timeguardian"
							+ "your OTP is :"+ otp +" valid for 2 mintue."
									+ "Thank you ";
					Mail.send(email, "TimeGuardian",msg);
					HttpSession session = request.getSession();
					session.setAttribute("page", "register");
					session.setAttribute("prof","s");
					session.setAttribute("stuinfo", stu);
					session.setAttribute("OTP", otp);
					session.setMaxInactiveInterval(500);
					result = 1;
				}
				out.print(result);
			}catch (ClassNotFoundException | SQLException e) {
				out.print(result);
				e.printStackTrace();
			}
		}
		else if(profession.equalsIgnoreCase("f")) {
			
			String department = request.getParameter("cord");
			int no_of_subjects = Integer.parseInt(request.getParameter("sos"));
			String[] subject_id = new String[no_of_subjects];
			FacultyBean fac=new FacultyBean();
			fac.setFname(fname);
			fac.setLname(lname);
			fac.setEmail(email);
			fac.setMobile(mobile);
			fac.setDepartment(department);
			fac.setSubject_no(no_of_subjects);
			for(int i=0;i<no_of_subjects;i++) {
				subject_id[i]=request.getParameter("c"+i);
			}
			fac.setSubject_id(subject_id);
			try {
				FacultyDao facdao=new FacultyDao();
				if(facdao.isEmailExists(email))
					result = -2;
				else if(facdao.isMobileExists(mobile))
					result = -3;
				else {
					int otp = new Random().nextInt(10000);
					String msg = "Welcome to timeguardian"
							+ "your OTP is :"+ otp +" valid for 2 mintue."
									+ "Thank you ";
					Mail.send(email, "TimeGuardian",msg);
					HttpSession session = request.getSession();
					session.setAttribute("page", "register");
					session.setAttribute("prof","f");
					session.setAttribute("facinfo", fac);
					session.setAttribute("OTP", otp);
					session.setMaxInactiveInterval(500);
					result = 1;
				}
				out.print(result);
			}catch (ClassNotFoundException | SQLException e) {
				out.print(result);
				e.printStackTrace();
			}
		}
		else {
			String dept = request.getParameter("dept");
			HodBean hod=new HodBean();
			hod.setFname(fname);
			hod.setLname(lname);
			hod.setEmail(email);
			hod.setMobile(mobile);
			hod.setDept(dept);
			try {
				HodDao hoddao=new HodDao();
				if(hoddao.isEmailExists(email))
					result = -2;
				else if(hoddao.isMobileExists(mobile))
					result = -3;
				else {
					int otp = new Random().nextInt(10000);
					String msg = "Welcome to timeguardian"
							+ "your OTP is :"+ otp +" valid for 2 mintue."
									+ "Thank you ";
					Mail.send(email, "TimeGuardian",msg);
					HttpSession session = request.getSession();
					session.setAttribute("page", "register");
					session.setAttribute("prof","h");
					session.setAttribute("hodinfo", hod);
					session.setAttribute("OTP", otp);
					session.setMaxInactiveInterval(500);
					result = 1;
				}
				out.print(result);
			}catch (ClassNotFoundException | SQLException e) {
				out.print(result);
				e.printStackTrace();
			}
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
