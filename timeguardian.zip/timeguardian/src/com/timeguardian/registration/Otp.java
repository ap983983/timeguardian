package com.timeguardian.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.timeguardian.beans.FacultyBean;
import com.timeguardian.beans.HodBean;
import com.timeguardian.beans.StudentBean;
import com.timeguardian.dao.FacultyDao;
import com.timeguardian.dao.HodDao;
import com.timeguardian.dao.StudentDao;

@WebServlet("/Otp")
public class Otp extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public Otp() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		int result=500;
		RequestDispatcher error = request.getRequestDispatcher("error.html");
		final int OTP = Integer.parseInt(request.getParameter("otp"));
		HttpSession session = request.getSession();
		final String page = (String)session.getAttribute("page");
		final int session_otp = Integer.parseInt(session.getAttribute("OTP").toString());
	
		switch (page) {
		case "register":
			final String prof = (String)session.getAttribute("prof");
			if(session_otp == OTP) {
				if(prof.equalsIgnoreCase("s")){
					try {
						StudentBean s =(StudentBean)session.getAttribute("stuinfo");
						result = new StudentDao().insertStudent(s);
						response.sendRedirect("reg_login/login.jsp");
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}else if(prof.equalsIgnoreCase("f")) {
					try {
						FacultyBean f =(FacultyBean)session.getAttribute("facinfo");
						result = new FacultyDao().insertFaculty(f);
						response.sendRedirect("reg_login/login.jsp");
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}else {
					try {
						HodBean h =(HodBean)session.getAttribute("hodinfo");
						result = new HodDao().insertHod(h);
						response.sendRedirect("reg_login/login.jsp");
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				out.print(result);
			}else {
				error.forward(request, response);
			}
			break;
		case "forget":
			final String prof1 = (String)session.getAttribute("prof");
			final String email = (String)session.getAttribute("email");
			if(session_otp == OTP) {
				if(prof1.equalsIgnoreCase("s")){	
					try {
						StudentDao update_password=new StudentDao();
						final String password = update_password.updatePasswordByEmail(email);
						String msg="your password is reseted.the password is: "+ password;
						Mail.send(email, "Your Password Reseted ", msg);
						response.sendRedirect("reg_login/login.jsp");
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}else if(prof1.equalsIgnoreCase("f")) {
					try {
						FacultyDao update_password=new FacultyDao();
						final String password = update_password.updatePasswordByEmail(email);
						String msg="your password is reseted.the password is: "+ password;
						Mail.send(email, "Your Password Reseted ", msg);
						response.sendRedirect("reg_login/login.jsp");
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}else {
					
				}
				out.print(result);
			}else {
				error.forward(request, response);
			}
			break;
		default:
			break;
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
