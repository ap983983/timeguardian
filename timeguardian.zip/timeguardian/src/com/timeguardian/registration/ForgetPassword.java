package com.timeguardian.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.timeguardian.dao.StudentDao;

@WebServlet("/ForgetPassword")
public class ForgetPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public ForgetPassword() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.setContentType("text/plaintext");
		PrintWriter out = response.getWriter();
		StudentDao user_exist;
		try {
			user_exist = new StudentDao();
			String prof=request.getParameter("profession");
			String email = request.getParameter("email");
			HttpSession session = request.getSession();
			if(user_exist.isEmailExists(email)) {
				Random r = new Random();
				int otp = r.nextInt(1000000);
				session.setAttribute("page","forget");
				session.setAttribute("prof",prof);
				session.setAttribute("email", email);
				session.setAttribute("OTP",otp);
				session.setMaxInactiveInterval(120);
				String msg = "<h2>Forget Password </h2><br><p> The OTP is : <br><h1>"+otp+"</h1> valid for 5 minute only <br></p><br><b>Thank you</b>";
				Mail.send(email, "Forget Password",msg);
				response.sendRedirect("reg_login/otp.html");
			}else {
				out.print("User data not found");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
