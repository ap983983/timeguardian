package com.timeguardian.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.timeguardian.dao.StudentDao;

@WebServlet("/Student")
public class Student extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public Student(){
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/plain");
		String token=request.getParameter("token");
		PrintWriter out = response.getWriter();
		try {
		StudentDao list = new StudentDao();
		if(token.equalsIgnoreCase("c")) {
				
				out.print(list.courseStudent());
		}else if(token.equalsIgnoreCase("b")){
			String course = request.getParameter("course");
			out.print(list.branchStudent(course));
		}
		}catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
