package com.timeguardian.beans;

public class SubjectBean {

	private String sub_id,sub_name,sub_image;

	public String getSub_id() {
		return sub_id;
	}

	public void setSub_id(String sub_id) {
		this.sub_id = sub_id;
	}

	public String getSub_name() {
		return sub_name;
	}

	public void setSub_name(String sub_name) {
		this.sub_name = sub_name;
	}

	public String getSub_image() {
		return sub_image;
	}

	public void setSub_image(String sub_image) {
		this.sub_image = sub_image;
	}
	
}
