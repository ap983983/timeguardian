package com.timeguardian.beans;

public class MessageBean {
	private int msgid;
	private String subject, message, documents, date;
	
	public int getMsgId() {
		return msgid;
	}
	public void setMsgId(int msgid) {
		this.msgid=msgid;
	}
	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDocuments() {
		return documents;
	}

	public void setDocuments(String documents) {
		this.documents = documents;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
}
