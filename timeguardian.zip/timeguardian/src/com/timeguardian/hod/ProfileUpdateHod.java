package com.timeguardian.hod;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.timeguardian.dao.HodDao;

/**
 * Servlet implementation class ProfileUpdateHod
 */
@WebServlet("/ProfileUpdateHod")
public class ProfileUpdateHod extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProfileUpdateHod() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String user=request.getParameter("");
		String email=request.getParameter("");
		String mobile=request.getParameter("");
		String password=request.getParameter("");
		try {
			HodDao update_hod=new HodDao();
			update_hod.updateEmail(user, email);
			update_hod.updateMobile(user, mobile);
			update_hod.updatePassword(user,password);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
