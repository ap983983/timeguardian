package com.timeguardian.hod;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.timeguardian.dao.HodDao;

@WebServlet("/AssignTaskHod")
public class AssignTaskHod extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public AssignTaskHod() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String msgsub=request.getParameter("subject");
		String msginfo=request.getParameter("editor_content");
		String[] facids=request.getParameterValues("facid");
		try {
			HodDao hodDao=new HodDao();
			hodDao.assignTaskHod(msgsub, msginfo, facids);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
