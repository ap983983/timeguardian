package com.timeguardian.admin;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.timeguardian.dao.AdminDao;

/**
 * Servlet implementation class Assigntask
 */
@WebServlet("/Assigntask")
public class Assigntask extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	
	public Assigntask() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String dept=request.getParameter("dept");
		String subject=request.getParameter("subject");
		String msginfo=request.getParameter("editor_content");
		try {
			AdminDao assigntask=new AdminDao();
			assigntask.assignTaskHod(subject,msginfo,dept);
			
			response.sendRedirect("admin/assigntask.jsp");
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
