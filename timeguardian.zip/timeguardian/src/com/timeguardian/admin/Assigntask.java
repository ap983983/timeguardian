package com.timeguardian.admin;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.timeguardian.dao.AdminDao;

/**
 * Servlet implementation class Assigntask
 */
@WebServlet("/Assigntask")
public class Assigntask extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	
	public Assigntask() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Enumeration<String> data=request.getParameterNames();
		ArrayList<String> msginfo=new ArrayList<>();
		while(data.hasMoreElements()) {
			msginfo.add(request.getParameter(data.nextElement()));
		}
		try {
			AdminDao assigntask=new AdminDao();
			assigntask.assignTaskHod(msginfo);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
