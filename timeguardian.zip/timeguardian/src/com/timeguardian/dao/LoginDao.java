package com.timeguardian.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.time.DBUtil.DBConnection;

public class LoginDao {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	String sql="";
	public LoginDao() throws ClassNotFoundException, SQLException {
		con = DBConnection.getCon();
	}
	public int loginUser(String prof, String user, String pass) throws SQLException, ClassNotFoundException {
		int status = 500;
		String table = (prof.equalsIgnoreCase("s"))?"student":(prof.equalsIgnoreCase("f"))?"faculty":"hod";
		if(statusUser(table, user) == 1) {
			sql="select password from ";
			table = table + " where " + table + "_id=? or email = ?";
			sql +=table;
			pst=con.prepareStatement(sql);
			pst.setString(1, user);
			pst.setString(2, user);
			rs=pst.executeQuery();
			if(rs.next()) {
				if(rs.getString(1).equals(pass)) {
					status =1;
				}
				else {
					status = -1;
				}
			}else {
				status = -2;
			}
		}
		return status;
	}
	/* [ status of the user ] */
	public int statusUser(String table, String user) throws SQLException {
		int status=1; 
		sql="select status from ";
		table = table + " where "+ table + "_id = ? or email = ?";
		sql+=table;
		pst=con.prepareStatement(sql);
		pst.setString(1, user);
		pst.setString(2, user);
		rs=pst.executeQuery();
		if(rs.next())
			status=rs.getInt(1);
		return status;
	}
}
