package com.timeguardian.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import com.time.DBUtil.DBConnection;

public class Firstyear {
	
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	String sql;
	public Firstyear() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated constructor stub
		con = DBConnection.getCon();
	}
	public ArrayList<String> rollnoList(String course,String branch) throws SQLException{
		ArrayList<String> rollno = new ArrayList<>();
		sql="select stud_id from student where course=? and branch=? and ( semester=7 or semester=8 )";
		pst=con.prepareStatement(sql);
		pst.setString(1, course);
		pst.setString(2, branch);
		rs=pst.executeQuery();
		while(rs.next()) {
			rollno.add(rs.getString(1));
		}
		return rollno;
	}
	public void insertMsg(ArrayList<String> rollno,String sub, String msg,String sub_id) throws SQLException {
		
		Iterator<String> itr=rollno.iterator();
		while(itr.hasNext()) {
		sql="insert into student_recenttask(msgsub,msginfo,msgdoc,stu_id,fac_id,sub_id) values(?,?,?,?,?,?)";
		pst=con.prepareStatement(sql);
		pst.setString(1,sub);
		pst.setString(2, msg);
		pst.setString(3,"dec");
		pst.setString(4,itr.next());
		pst.setString(5,"fac");
		pst.setString(6, sub_id);
		pst.executeUpdate();
		
		}
		con.close();
	}
	public ArrayList<String> courseList() throws SQLException{
		ArrayList<String> course=new ArrayList<>();
		sql="select distinct course from subjects where semester=1 or semester=2";
		pst=con.prepareStatement(sql);
		rs=pst.executeQuery();
		while(rs.next()) {
			course.add(rs.getString(1));
		}
		return course;
	}


}
