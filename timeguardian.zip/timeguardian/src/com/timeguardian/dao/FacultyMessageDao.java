package com.timeguardian.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

import com.time.DBUtil.DBConnection;
import com.timeguardian.beans.MessageBean;

public class FacultyMessageDao {
	
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	public FacultyMessageDao() throws ClassNotFoundException, SQLException {
		con = DBConnection.getCon();
	}
	public HashMap<Integer, ArrayList<MessageBean>> getCurrentMsg(String user) throws SQLException{
		SimpleDateFormat df= new SimpleDateFormat("yyyy-MM-dd");
		String today_date = df.format(new Timestamp(System.currentTimeMillis()));
		ArrayList<MessageBean> today_task = new ArrayList<>();
		ArrayList<MessageBean> previous_task = new ArrayList<>();
		HashMap<Integer, ArrayList<MessageBean>> hashMap = new HashMap<>();
		String sql="select msgsub,msginfo,msgdoc,msgdate from faculty_recenttask where fac_id=?";
		pst=con.prepareStatement(sql);
		pst.setString(1, user);
		rs = pst.executeQuery();
		while(rs.next()) {
			String msgsub=rs.getString("msgsub");
			String msginfo=rs.getString("msginfo");
			String msgdoc=rs.getString("msgdoc");
			String timestamp=rs.getString("msgdate");
			MessageBean msg=new MessageBean();
			msg.setSubject(msgsub);
			msg.setMessage(msginfo);
			msg.setDocuments(msgdoc);
			msg.setDate(timestamp);
			String date[] = timestamp.split(" ");
			if(date[0].equals(today_date)) {
				today_task.add(msg);
				//System.out.println("today:" + msgsub);
			}else {
				//System.out.println("prev:" + msgsub);
				previous_task.add(msg);
			}
		}
		hashMap.put(1, today_task);
		hashMap.put(2, previous_task);
		return hashMap;
	}
	public TreeMap<String,Integer> subjectId(String user) throws SQLException {
		TreeMap<String, Integer> sub_count = new TreeMap<>();
		String sql="select sub_id from faculty_recenttask where fac_id = ? and msgdate = CURRENT_TIMESTAMP()";
		pst=con.prepareStatement(sql);
		pst.setString(1, user);
		rs=pst.executeQuery();
		while (rs.next()) {
			String sub=rs.getString("sub_id");
			if(sub_count.containsKey(sub)) {
				sub_count.replace(sub, sub_count.get(sub).intValue()+1);
			}else {
				sub_count.put(sub, 0);
			}
		}
		return sub_count;
	}

}
