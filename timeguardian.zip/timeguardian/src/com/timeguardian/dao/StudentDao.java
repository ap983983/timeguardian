package com.timeguardian.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

import com.time.DBUtil.DBConnection;
import com.timeguardian.beans.StudentBean;
import com.timeguardian.beans.SubjectBean;


public class StudentDao {
	Connection con;
	PreparedStatement pst,pst1;
	ResultSet rs;
	
	public StudentDao() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated constructor stub
		con = DBConnection.getCon();
	}
	
	public int insertStudent(StudentBean s) throws ClassNotFoundException, SQLException {	
				pst= con.prepareStatement("insert into student(student_id,fname,lname,email,mobile,course,branch,semester,section) values(?,?,?,?,?,?,?,?,?)");
				//System.out.println(s.getUsername());
				pst.setString(1,s.getUsername());
				pst.setString(2,s.getFname());
				pst.setString(3,s.getLname());
				pst.setString(4,s.getEmail());
				pst.setString(5,s.getMobile());
				pst.setString(6,s.getCourse());
				pst.setString(7,s.getBranch());
				pst.setString(8,s.getSemester());
				pst.setString(9,s.getSection());
				int r =(pst.executeUpdate() == 1) ? 1 : 500 ;
				con.close();
				return r;
	}
	
	
	public String courseStudent() throws SQLException {
		String course="#";
		String sql="select distinct course from subjects";
		pst=con.prepareStatement(sql);
		rs=pst.executeQuery();
		while(rs.next()) {
			course = rs.getString(1) + course;
		}
		return course;
	}
	
	
	public String branchStudent(String course) throws SQLException {
		String branch="#";
		String sql="select distinct branch from subjects where course = ?";
		pst=con.prepareStatement(sql);
		pst.setString(1,course);
		rs=pst.executeQuery();
		while(rs.next()) {
			branch = rs.getString(1) + branch;
		}
		return branch;
	}
	
	public void updateProfile(String user,String profile) throws SQLException {
		String sql="update student set profile_image = ? where student_id=?";
		pst=con.prepareStatement(sql);
		pst.setString(1, profile);
		pst.setString(2, user);
		pst.executeUpdate();
	}
	public ArrayList<StudentBean> studentsList(int status) throws SQLException {
		StudentBean stubean;
		ArrayList<StudentBean> stulist=new ArrayList<>();
		String sql="select * from student where status=?";
		pst=con.prepareStatement(sql);
		pst.setInt(1, status);
		rs=pst.executeQuery();
		while(rs.next()) {
			stubean=new StudentBean();
			stubean.setUsername(rs.getString("student_id"));
			stubean.setFname(rs.getString("fname"));
			stubean.setLname(rs.getString("lname"));
			stubean.setEmail(rs.getString("email"));
			stubean.setMobile(rs.getString("mobile"));
			stubean.setCourse(rs.getString("course"));
			stubean.setBranch(rs.getString("branch"));
			stubean.setSemester(rs.getString("semester"));
			stubean.setSection(rs.getString("section"));
			stulist.add(stubean);
		}
		return stulist;
	}
	public StudentBean getStudentInfo(String user) throws SQLException {
		StudentBean stu=new StudentBean();
		String sql="select * from student where student_id = ?";
		pst=con.prepareStatement(sql);
		pst.setString(1,user);
		rs = pst.executeQuery();
		while(rs.next()) {
			stu = new StudentBean(rs.getString("student_id"),rs.getString("fname"),rs.getString("lname"),rs.getString("mobile"),rs.getString("email"),rs.getString("course"),rs.getString("branch"),rs.getString("semester"),rs.getString("section"));
			stu.setProfile(rs.getString("profile_image"));
		}
		return stu;
	}
	public String updatePasswordByEmail(String email) throws SQLException {
		Random random = new Random();
		final String password = random.nextInt(40000)+"@time123";
		String sql="update student set password=? where email=?";
		pst=con.prepareStatement(sql);
		pst.setString(1, password);
		pst.setString(2, email);
		pst.executeUpdate();
		con.close();
		return password;
	}
	
	public int updatePasswordById(String user,String oldpass,String newpass) throws SQLException {
		int res=0;
		String sql="select password from student where student_id=?";
		pst=con.prepareStatement(sql);
		pst.setString(1, user);
		rs=pst.executeQuery();
		if(rs.next()) {
			if(rs.getString("password").equals(oldpass)){
				sql="update student set password=? where student_id= ?";
				pst=con.prepareStatement(sql);
				pst.setString(1,newpass);
				pst.setString(2,user);
				res= pst.executeUpdate();
			}else {
				res= 2;
			}
		}
		con.close();
		return res;
	}
	
	
	
	public int updateEmail(String user,String email) throws SQLException {
		String sql="update student set email=? where stud_id = ?";
		pst=con.prepareStatement(sql);
		pst.setString(1,email);
		pst.setString(2,user);
		return pst.executeUpdate();
	}
	
	
	public int updateMobile(String user ,String mobile) throws SQLException {
		String sql="update student set mobile = ? where stud_id=?";
		pst=con.prepareStatement(sql);
		pst.setString(1,mobile);
		pst.setString(2,user);
		return pst.executeUpdate();
	}
	
	
	public int deleteUser(String user) throws SQLException {
		String sql="delete from student where user = ?";
		pst=con.prepareStatement(sql);
		pst.setString(1,user);
		return pst.executeUpdate();
	}
	
		
	public ArrayList<SubjectBean> getSubject(String course,String branch,String semester) throws SQLException {
		ArrayList<SubjectBean> sb=new ArrayList<>();
		String sql="select sub_id,sub_name,image from subjects where course=? and branch=? and semester=?";
		pst=con.prepareStatement(sql);
		pst.setString(1,course);
		pst.setString(2, branch);
		pst.setString(3, semester);
		rs=pst.executeQuery();
		while(rs.next()) {
			SubjectBean sub=new SubjectBean();
			sub.setSub_id(rs.getString("sub_id"));
			sub.setSub_name(rs.getString("sub_name"));
			sub.setSub_image(rs.getString("image"));
			sb.add(sub);
		}
		return sb;
	}
	
	
	public boolean isUserExists(String user) throws SQLException {
		pst=con.prepareStatement("select student_id from student where student_id = ?");
		pst.setString(1,user);
		rs=pst.executeQuery();
		while(rs.next())
			return true;
		return false;
	}
	public boolean isEmailExists(String email) throws SQLException {
		pst=con.prepareStatement("select email from student where email = ?");
		pst.setString(1, email);
		rs=pst.executeQuery();
		while(rs.next())
			return true;
		return false;
	}
	public boolean isMobileExists(String mobile) throws SQLException {
		pst=con.prepareStatement("select mobile from student where mobile = ?");
		pst.setString(1, mobile);
		rs=pst.executeQuery();
		while(rs.next())
			return true;
		return false;
	}
}
