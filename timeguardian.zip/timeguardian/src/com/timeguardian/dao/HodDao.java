package com.timeguardian.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.time.DBUtil.DBConnection;
import com.timeguardian.beans.HodBean;

public class HodDao {

	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	String sql;
	public HodDao() throws ClassNotFoundException, SQLException {
		con = DBConnection.getCon();
	}
	public String insertHod(HodBean h) throws ClassNotFoundException, SQLException {		
			String hod_id=getEmployeeID(h.getFname(), h.getLname());
			pst= con.prepareStatement("insert into hod(hod_id,fname,lname,email,mobile,dept) values(?,?,?,?,?,?)");
			pst.setString(1,hod_id);
			pst.setString(2, h.getFname());
			pst.setString(3, h.getLname());
			pst.setString(4, h.getEmail());
			pst.setString(5, h.getMobile());
			pst.setString(6, h.getDept());
			int r=(pst.executeUpdate()==1)?1:500;
			con.close();
			return hod_id;
	}
	public HodBean hodInfo(String user) throws SQLException {
		HodBean hodinfo = new HodBean();
		String sql="select fname,lname,email,mobile,dept from hod where hod_id=?";
		pst=con.prepareStatement(sql);
		pst.setString(1,user);
		rs = pst.executeQuery();
		while(rs.next()) {
			hodinfo.setFname(rs.getString("fname"));
			hodinfo.setLname(rs.getString("lname"));
			hodinfo.setEmail(rs.getString("email"));
			hodinfo.setMobile(rs.getString("mobile"));
			hodinfo.setDept(rs.getString("dept"));
		}
		return hodinfo;
	}
	public ArrayList<HodBean> hodList(int status) throws SQLException {
		HodBean hodbean;
		ArrayList<HodBean> hodlist=new ArrayList<>();
		String sql="select * from hod where status=?";
		pst=con.prepareStatement(sql);
		pst.setInt(1, status);
		rs=pst.executeQuery();
		while(rs.next()) {
			hodbean=new HodBean();
			hodbean.setHod_id(rs.getString("hod_id"));
			hodbean.setFname(rs.getString("fname"));
			hodbean.setLname(rs.getString("lname"));
			hodbean.setEmail(rs.getString("email"));
			hodbean.setMobile(rs.getString("mobile"));
			hodlist.add(hodbean);
		}
		return hodlist;
	}
	public int updatePassword(String user,String password) throws SQLException {
		String sql="update hod set password=? where hod_id=?";
		pst=con.prepareStatement(sql);
		pst.setString(1, password);
		pst.setString(2, user);
		return pst.executeUpdate();		
	}
	public int updateEmail(String user,String email) throws SQLException {
		String sql="update hod set email=? where hod_id = ?";
		pst=con.prepareStatement(sql);
		pst.setString(1,email);
		pst.setString(2,user);
		return pst.executeUpdate();
	}
	public int updateMobile(String user ,String mobile) throws SQLException {
		String sql="update hod set mobile = ? where hod_id=?";
		pst=con.prepareStatement(sql);
		pst.setString(1,mobile);
		pst.setString(2,user);
		return pst.executeUpdate();
	}
	public int deleteUser(String user) throws SQLException {
		String sql="delete from hod where hod_id = ?";
		pst=con.prepareStatement(sql);
		pst.setString(1,user);
		return pst.executeUpdate();
	}
	public String getDepartment() throws SQLException {
		sql="select distinct branch from subjects";
		pst=con.prepareStatement(sql);
		rs = pst.executeQuery();
		String dept="#";
		while(rs.next()) {
			dept = rs.getString(1) + dept;
		}
		return dept;
	}
	
	public static String getEmployeeID(String fname,String lname) throws SQLException, ClassNotFoundException {
		String empid="";
		if(lname != "") {
			empid=fname.substring(0, 2)+lname.charAt(0);
		}else {
			empid=fname.substring(0,3);
		}
		empid = empid.toUpperCase() +"068" +new HodDao().countFields()+1;
		return empid;	
	}
	
	public int countFields() throws SQLException {
		sql="select count(*) from hod";
		pst=con.prepareStatement(sql);
		rs = pst.executeQuery();
		if(rs.next())
			return rs.getInt(1);
		return 0;
	}
	
	public boolean isUserExists(String user) throws SQLException {
		pst=con.prepareStatement("select hod_id from hod where hod_id = ?");
		pst.setString(1,user);
		rs=pst.executeQuery();
		while(rs.next())
			return true;
		return false;
	}
	public boolean isEmailExists(String email) throws SQLException {
		pst=con.prepareStatement("select email from hod where email = ?");
		pst.setString(1, email);
		rs=pst.executeQuery();
		while(rs.next())
			return true;
		return false;
	}
	public boolean isMobileExists(String mobile) throws SQLException {
		pst=con.prepareStatement("select mobile from hod where mobile = ?");
		pst.setString(1, mobile);
		rs=pst.executeQuery();
		while(rs.next())
			return true;
		return false;
	}
	public ArrayList<String> facultyEmailList(String dept) throws SQLException{
		ArrayList<String> emaillist=new ArrayList<>();
		sql="select faculty_id,fname,lname from faculty where dept=?";
		pst=con.prepareStatement(sql);
		pst.setString(1, dept);
		rs=pst.executeQuery();
		while(rs.next()) {
			emaillist.add(rs.getString("faculty_id")+"#"+rs.getString("fname")+rs.getString("lname"));
		}
		return emaillist;
	}
	public void assignTaskHod(String hodid, String msgsub,String msginfo,String[] faculty_id) throws SQLException, ClassNotFoundException {
			sql="insert into faculty_recenttask(msgsub,msginfo,hod_id,fac_id) values(?,?,?,?)";
			for(int i=0;i<faculty_id.length;i++) {
				pst=con.prepareStatement(sql);
				pst.setString(1,msgsub);
				pst.setString(2, msginfo);
				pst.setString(3, hodid);
				pst.setString(4, faculty_id[i]);
				pst.executeUpdate();
			}
	}

}
