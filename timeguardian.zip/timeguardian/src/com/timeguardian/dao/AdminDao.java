package com.timeguardian.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.time.DBUtil.DBConnection;

public class AdminDao {

	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	String sql;
	public AdminDao() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated constructor stub
		con=DBConnection.getCon();
	}
	public boolean authenticate(String username,String password) throws SQLException {
		boolean flag=false;
		sql="select count(*) from admin where username=? and password=?";
		pst=con.prepareStatement(sql);
		pst.setString(1, username);
		pst.setString(2, password);
		rs=pst.executeQuery();
		if (rs.next() && rs.getInt(1) == 1) {
			flag=true;
		}
		return flag;
	}
	public void togglestatus(String prof,String user) throws SQLException {
		sql="update " + prof+" set status = (1 - status) where "+prof+"_id=?";
		pst=con.prepareStatement(sql);
		pst.setString(1, user);
		pst.executeUpdate();
	}
	public void deleteRequest(String prof,String user) throws SQLException {
		sql="delete from " + prof+" where "+prof+"_id=?";
		pst=con.prepareStatement(sql);
		pst.setString(1, user);
		pst.executeUpdate();
	}
	public void assignTaskHod(ArrayList<String> msginfo) {
//		sql="insert into hod_recenttask values(?,?,?,?,?)";
//		pst=con.prepareStatement(sql);
//		pst.setString(1, msg);
//		
	}
}
