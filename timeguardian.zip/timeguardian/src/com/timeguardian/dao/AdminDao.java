package com.timeguardian.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.time.DBUtil.DBConnection;

public class AdminDao {

	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	String sql;
	public AdminDao() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated constructor stub
		con=DBConnection.getCon();
	}
	public boolean authenticate(String username,String password) throws SQLException {
		boolean flag=false;
		sql="select count(*) from admin where username=? and password=?";
		pst=con.prepareStatement(sql);
		pst.setString(1, username);
		pst.setString(2, password);
		rs=pst.executeQuery();
		if (rs.next() && rs.getInt(1) == 1) {
			flag=true;
		}
		return flag;
	}
	public void togglestatus(String prof,String user) throws SQLException {
		sql="update " + prof+" set status = (1 - status) where "+prof+"_id=?";
		pst=con.prepareStatement(sql);
		pst.setString(1, user);
		pst.executeUpdate();
	}
	public void deleteRequest(String prof,String user) throws SQLException {
		sql="delete from " + prof+" where "+prof+"_id=?";
		pst=con.prepareStatement(sql);
		pst.setString(1, user);
		pst.executeUpdate();
	}
	public void assignTaskHod(String msgsub,String msginfo,String dept) throws SQLException, ClassNotFoundException {
		String Id = new AdminDao().HodId(dept);
		if(Id != "") {
			sql="insert into hod_recent_task(msgsub,msginfo,hod_id) values(?,?,?)";
			pst=con.prepareStatement(sql);
			pst.setString(1,msgsub);
			pst.setString(2, msginfo);
			pst.setString(3, Id);
			pst.executeUpdate();
		}	
	}
	public String HodId(String dept) throws SQLException {
		sql="select hod_id from hod where dept=?";
		pst=con.prepareStatement(sql);
		pst.setString(1, dept);
		rs=pst.executeQuery();
		rs.next();
		return rs.getString("hod_id");
	}
}
