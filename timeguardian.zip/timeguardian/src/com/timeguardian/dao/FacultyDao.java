package com.timeguardian.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

import com.time.DBUtil.DBConnection;
import com.timeguardian.beans.FacultyBean;
public class FacultyDao {

	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	String sql;
	public FacultyDao() throws ClassNotFoundException, SQLException {
		con = DBConnection.getCon();
	}
	public String insertFaculty(FacultyBean f) throws ClassNotFoundException, SQLException {	
			String sql="";
			int j=0;		
			String faculty_id=getEmployeeID(f.getFname(), f.getLname());
			pst= con.prepareStatement("insert into faculty(faculty_id,fname,lname,email,mobile,dept,subjectno) values(?,?,?,?,?,?,?)");
			pst.setString(1,faculty_id);
			pst.setString(2, f.getFname());
			pst.setString(3, f.getLname());
			pst.setString(4, f.getEmail());
			pst.setString(5, f.getMobile());
			pst.setString(6, f.getDepartment());
			pst.setInt(7, f.getSubject_no());
			pst.executeUpdate();
			
			String[] sub=f.getSubject_id();
			
			System.out.println(sub.length);
			sql="insert into faculty_subject(";
			for(int i=1;i<=sub.length;i++) {
				sql+="sub"+i+",";
			}
			sql+="fac_id) values(";
			for(int i=0;i < sub.length;i++) {
				sql+="?,";
			}
			sql+="?)";
			
			pst=con.prepareStatement(sql);
			for(j=0;j<sub.length;j++) {
				pst.setString(j+1, sub[j]);
			}
			pst.setString(j+1,faculty_id);
			int r =(pst.executeUpdate() == 1) ? 1 : 500 ;
			con.close();
			return faculty_id;
	}
	public FacultyBean facultyInfo(String user) throws SQLException {
		FacultyBean facinfo = new FacultyBean();
		String subjects[] = null;
		String sql="select f.fname,f.lname,f.email,f.mobile,f.dept,f.subjectno,s.sub1,s.sub2,s.sub3"
					+ " from faculty f , faculty_subject s where f.faculty_id = ? and s.fac_id=?";
		pst=con.prepareStatement(sql);
		pst.setString(1,user);
		pst.setString(2,user);
		rs = pst.executeQuery();
		while(rs.next()) {
			int n=rs.getInt("subjectno");
			subjects=new String[n+1];
			for(int i=1;i<=n;i++) {
				String s=rs.getString("sub"+i);
				if(s != "")
					subjects[i]=s;
			}
			facinfo.setFname(rs.getString("fname"));
			facinfo.setLname(rs.getString("lname"));
			facinfo.setEmail(rs.getString("email"));
			facinfo.setMobile(rs.getString("mobile"));
			facinfo.setDepartment(rs.getString("dept"));
			facinfo.setSubject_no(n);
			facinfo.setSubject_id(subjects);
		}
		return facinfo;
	}
	public ArrayList<FacultyBean> facultyList(int status) throws SQLException {
		FacultyBean facbean;
		ArrayList<FacultyBean> faclist=new ArrayList<>();
		String sql="select * from faculty where status=?";
		pst=con.prepareStatement(sql);
		pst.setInt(1, status);
		rs=pst.executeQuery();
		while(rs.next()) {
			facbean=new FacultyBean();
			facbean.setFaculty_id(rs.getString("faculty_id"));
			facbean.setFname(rs.getString("fname"));
			facbean.setLname(rs.getString("lname"));
			facbean.setEmail(rs.getString("email"));
			facbean.setMobile(rs.getString("mobile"));
			facbean.setDepartment(rs.getString("dept"));
			faclist.add(facbean);
		}
		return faclist;
	}
	public int updatePassword(String user,String password) throws SQLException {
		String sql="update faculty set password=? where faculty_id=?";
		pst=con.prepareStatement(sql);
		pst.setString(1, password);
		pst.setString(2, user);
		return pst.executeUpdate();	
	}
	public int updateEmail(String user,String email) throws SQLException {
		String sql="update faculty set email=? where faculty_id = ?";
		pst=con.prepareStatement(sql);
		pst.setString(1,email);
		pst.setString(2,user);
		return pst.executeUpdate();
	}
	public int updateMobile(String user ,String mobile) throws SQLException {
		String sql="update faculty set mobile = ? where faculty_id=?";
		pst=con.prepareStatement(sql);
		pst.setString(1,mobile);
		pst.setString(2,user);
		return pst.executeUpdate();
	}
	public int deleteUser(String user) throws SQLException {
		String sql="delete from faculty where faculty_id = ?";
		pst=con.prepareStatement(sql);
		pst.setString(1,user);
		return pst.executeUpdate();
	}
	public String getSubjects() throws SQLException {
		String subjects="<option value='' selected disabled'>Select Subjects</option>";
		sql="select sub_id,sub_name from subjects";
		pst=con.prepareStatement(sql);
		rs=pst.executeQuery();
		while(rs.next()) {
			subjects += "<option value="+rs.getString("sub_id")+">"+rs.getString("sub_id")+" : "+rs.getString("sub_name")+"</option>";
		}
		return subjects;
	}
	public String getDepartment() throws SQLException {
		sql="select distinct branch from subjects";
		pst=con.prepareStatement(sql);
		rs = pst.executeQuery();
		String dept="<option value='' selected disabled>Select Department</option>";
		while(rs.next()) {
			dept+="<option value="+rs.getString(1)+">"+rs.getString(1)+"</option>";
		}
		return dept;
	}
	
	public static String getEmployeeID(String fname,String lname) throws SQLException, ClassNotFoundException {
		String empid="";
		if(lname != null) {
			empid=fname.substring(0, 2)+lname.charAt(0);
		}else {
			empid=fname.substring(0,3);
		}
		empid = empid.toUpperCase() +"068" +new FacultyDao().countFields()+1;
		return empid;	
	}
	
	public int countFields() throws SQLException {
		sql="select count(*) from faculty";
		pst=con.prepareStatement(sql);
		rs = pst.executeQuery();
		if(rs.next())
			return rs.getInt(1);
		return 0;
	}
	public String updatePasswordByEmail(String email) throws SQLException {
		Random random = new Random();
		final String password = random.nextInt(40000)+"@time123";
		String sql="update faculty set password=? where email=?";
		pst=con.prepareStatement(sql);
		pst.setString(1, password);
		pst.setString(2, email);
		pst.executeUpdate();
		con.close();
		return password;
	}
	public int status(String user) throws SQLException {
		sql="select status from faculty where faculty_id=?";
		pst=con.prepareStatement(sql);
		pst.setString(1, user);
		rs = pst.executeQuery();
		rs.next();
		int s =(rs.getInt(1)==1)?0:1;
		sql="update faculty set status = ? where user = ?";
		pst=con.prepareStatement(sql);
		pst.setString(1, user);
		pst.setInt(2, s);
		return pst.executeUpdate();
	}
	public boolean isUserExists(String user) throws SQLException {
		pst=con.prepareStatement("select faculty_id from faculty where faculty_id = ?");
		pst.setString(1,user);
		rs=pst.executeQuery();
		while(rs.next())
			return true;
		return false;
	}
	public boolean isEmailExists(String email) throws SQLException {
		pst=con.prepareStatement("select email from faculty where email = ?");
		pst.setString(1, email);
		rs=pst.executeQuery();
		while(rs.next())
			return true;
		return false;
	}
	public boolean isMobileExists(String mobile) throws SQLException {
		pst=con.prepareStatement("select mobile from faculty where mobile = ?");
		pst.setString(1, mobile);
		rs=pst.executeQuery();
		while(rs.next())
			return true;
		return false;
	}
	public ArrayList<String> studentEmailList(String course, String branch, String section) throws SQLException{
		ArrayList<String> emaillist=new ArrayList<>();
		sql="select student_id,fname,lname from student where course=? and branch=? and section=?";
		pst=con.prepareStatement(sql);
		pst.setString(1, course);
		pst.setString(2, branch);
		pst.setString(3, section);
		rs=pst.executeQuery();
		while(rs.next()) {
			emaillist.add(rs.getString("student_id")+"#"+rs.getString("fname")+rs.getString("lname"));
		}
		return emaillist;
	}
	public void assignTaskHod(String facid, String msgsub,String msginfo,String[] student_id,String sub_id) throws SQLException, ClassNotFoundException {
		sql="insert into student_recenttask(msgsub,msginfo,stu_id,fac_id,sub_id) values(?,?,?,?,?)";
		for(int i=0;i<student_id.length;i++) {
			pst=con.prepareStatement(sql);
			pst.setString(1,msgsub);
			pst.setString(2, msginfo);
			pst.setString(3, student_id[i]);
			pst.setString(4, facid);
			pst.setString(5, sub_id);
			pst.executeUpdate();
		}
}
}
