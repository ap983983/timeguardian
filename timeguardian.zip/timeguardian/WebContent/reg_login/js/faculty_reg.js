$(document).ready(function(){
	/*-------------------
    [ VARIABLE ]  
    ---------------------*/
	var name_reg =/^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$/;
    var mob_reg = /^(\+\d{1,3}[- ]?)?\d{10}$/;
    var email_reg = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
    var rollno_reg = /[0-9]{10}/;
	fname = $('#fname');
    lname = $('#lname');
    email = $('#email');
    mobile = $('#mobile');
	dept=$('#dept');
	subjects=$('#subjects');
	for(i=1;i<=3;i++){
		$('#sub'+i).attr({
			disabled:true
		});
	}
	$.ajax({
		url:'../Faculty',
		method:'POST',
		data:'token=1',
		success:function(res){
			dept.html(res);
		}
	});
	subjects.change(function(){
		var n = $(this).val();
		$.ajax({
    		url:'../Faculty',
    		data:'token=2',
    		method:'GET',
    		success:function(res){
    			for (i = 1; i <= n; i++) {
    				$('#sub'+i).html(res);
    				$('#sub'+i).attr({disabled:false});
                }
    		}
    	});
	});
	
	// ---------------- Form Submition ------------- //
	$('form[id="reg-form"]').submit(function (e){
	    e.preventDefault();
	    f_name_arr = new String(fname.val()).split();
	    l_name_arr = new String(lname.val()).split();
	    if(f_name_arr.length > 1 || l_name_arr > 1){
	        alert('please enter only one name without space');
	    }
	    else if(!name_reg.test(fname.val())){
	        fname.val("");
	        fname.attr({"placeholder":"Enter Correct Name"});
	    }
	    else if(lname.val() != "" &&  !name_reg.test(lname.val())){
	        lname.val("");
	        lname.attr("placeholder","Enter Correct name");
	    }
	    else if(!mob_reg.test(mobile.val())){
	        mobile.val("");
	        mobile.attr("placeholder","enter correct mobile");
	    }
	    else if(!email_reg.test(email.val())){
	        email.val("");
	        email.attr("placeholder","enter correct email");
	    }
	    else{
	    	$('.register').attr({disabled:true,tabindex:-1});
	        data="prof=f&fname="+ fname.val() +"&lname="+ lname.val() +"&mobile="+ mobile.val() +"&email="+ email.val()+"&dept="+dept.val()+"&subjects="+subjects.val()+"&sub1="+$('#sub1').val()+"&sub2="+$('#sub2').val()+"&sub3="+$('#sub3').val();
	        $.ajax({
	            url:'../Register',
	            method:'get',
	            data:data,
	            success:function(res){
	            	$('.register').attr({disabled:false})
	                if(res == -1){
	                    rollno.val("");
	                    rollno.attr({"placeholder":"Already Exists "});
	                   } 
	                   else if(res == -2){
	                     email.val("");
	                     email.attr({"placeholder" : "Email already exists"});
	                   }
	                   else if(res == -3){
	                     mobile.val("");
	                     mobile.attr({"placeholder" : "Mobile already exists"});
	                   }
	                   else if(res == 1){
	                	 alert("OTP send to email ID.please check");
	                     window.location.href='otp.html';
	                   }else{
	                	  alert('Error! occured');
	                	  location.reload(true);
	                   }
	            },
	        });
	    }
	});
});