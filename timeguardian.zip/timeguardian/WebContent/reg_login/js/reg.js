course = {
    "1":"B.Tech",
    "2" : "BCA",
    "3" :"MBA",
    "4" :"M.Tech",
};
branch = {
    "CSE":"Computer Science",
}

// for faculty 
dept={"B.Tech" : "B.tech"}

//
section=['A','B','C','D','E','F'];

var subjects = ['artificial intelligence','cryptogrphy'];
var student=['rollno','semester','section'];
subject = { "1": "test 1", "2": "test 2" };

/*--------------------------
    [ SIGN UP JS ]
---------------------------*/
$(document).ready(function(){
    
    /*-------------------
    [ COMMON VARIABLE ]  
    ---------------------*/
    var fac_stu_1 = $('.fac-stu-1');
    var fac_stu_2 = $('.fac-stu-2');
    var fac_stu_3 = $('.fac-stu-3');
    var name_reg =/^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$/;
    var mob_reg = /^(\+\d{1,3}[- ]?)?\d{10}$/;
    var email_reg = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
    var rollno_reg = /[0-9]{10}/;

    fname = $('#fname');
    lname = $('#lname');
    mobile = $('#mobile');
    email = $('#email');
    pro=$("#pro");

    var rss='',fdept='',fsubjects='',rss='',opt='',proffesion;
    /*-------------------------------*/ 
    fac_stu_1.hide();
    fac_stu_2.hide();
    fac_stu_3.hide();

    pro.change(function(){
        proffesion = new String(pro.val()).toLowerCase();  
        if( proffesion == 'f'){
            fdept = '<option value="" selected disabled>Your Department</option><br/>';
            fsubjects = '<option value="" selected disabled>No. of Subjects</option><br/>';
            fac_stu_1.show("slow",function(){
            	$('#fac-stu-cd').attr({"required":true});
            	$.ajax({
            		url:'../Faculty',
            		method:'POST',
            		data:'token=1',
            		success:function(res){
            			dept = new String(res).split('#');
            			for(let i=0; i < dept.length; i++)
            				fdept+='<option value='+dept[i]+ '>' +dept[i]+ '</option><br/>';
            			$('#fac-stu-cd').html(fdept);
            		}
            	});
            });
            fac_stu_2.show(function(){
                $('#fac-stu-ss').attr({"required":true});
                for(let i=1;i<=3;i++)
                    fsubjects += "<option value=" + i + ">" + i +"</option><br/>";
                $('#fac-stu-ss').html(fsubjects);
            });
            fac_stu_3.hide("slow",function(){
                fac_stu_3.html('');
                $('#fac-stu-cd').attr({"required":false});
                $('#fac-stu-ss').attr({"required":false});
            });
        }
        else if(proffesion == "s"){
        	fdept = '<option value="" selected disabled>Your Course* </option>';
        	$.ajax({
        		url:'../Student',
        		method:'POST',
        		data:"token="+"c",
        		success:function(res){
        			course = res.trim().split("#");
        			for(let i = 0 ; i < course.length-1 ;i++ ){
        				fdept += "<option value=" + course[i] + ">" + course[i] +"</option><br/>";
        			}
        			fac_stu_1.show("slow",function(){
                        $('#fac-stu-cd').attr({"required":true});
                        $('#fac-stu-cd').html(fdept);
                    });
        		}
        	});
            
            fac_stu_2.show("slow",function(){
            	fsubjects = '<option value="" selected disabled> Your Branch* <option>';
            	$('#fac-stu-cd').change(function(){
            		var course = $(this).val();
            		$.ajax({
            			url:'../Student',
            			method:'POST',
            			data:'token=b&course='+course,
            			success:function(res){
            				
            				var branch=res.trim().split('#');
            				for(let i=0;i<branch.length-1;i++){
            					fsubjects += "<option value=" + branch[i] + ">" + branch[i] +"</option>";
            				}
            				$('#fac-stu-ss').attr({"required":true});
                            $('#fac-stu-ss').html(fsubjects);
            			}
            		});
            	});    
            });
            fac_stu_3.show("slow",function(){
                rss='',opt='';
                for (let i = 0; i < student.length - 1; i++) {
                    var str=student[i];
                    rss+="<div class='col-lg-4 col-md-4'><div class='form-group'><label for='"+str+"' class='sr-only'>'"+str+"'</label>"+
                        "<input id='"+str+"' class='form-control input-form' type='number' placeholder='Your "+str+"*' min='1' max='8' required></div></div>";   
                }
                for (let i = 0; i < section.length; i++) {
                  opt += '<option value='+section[i]+">"+section[i]+"</option>"; 
                }           
                rss += "<div class='col-lg-4 col-md-4'<div class='form-group'><select class='custom-select input-form' id='section'>"+opt+"</select></div>";
                fac_stu_3.html(rss);
            });
        }
        else{
            
            fdept = '<option value="" selected disabled>Your Department</option><br/>';
            fac_stu_1.show("slow",function(){
            	$('#fac-stu-cd').attr({"required":true});
            	$.ajax({
            		url:'../Faculty',
            		method:'POST',
            		data:'token=1',
            		success:function(res){
            			dept = new String(res).split('#');
            			for(let i=0; i < dept.length; i++)
            				fdept+='<option value='+dept[i]+ '>' +dept[i]+ '</option><br/>';
            			$('#fac-stu-cd').html(fdept);
            		}
            	});
            });
            fac_stu_2.hide();
            fac_stu_3.hide("slow",function(){
                $(this).html('');
                $('#fac-stu-cd').attr({"required":false});
                $('#fac-stu-ss').attr({"required":false});
            });
        }
    });

    $('#fac-stu-ss').change(function(){
        if(proffesion == "f"){
            var temp = '', sub ='';
            var n = parseInt($(this).val());
            fac_stu_3.show("slow",function(){
            	$.ajax({
            		url:'../Faculty',
            		data:'token=2',
            		method:'GET',
            		success:function(res){
            			for (let i = 0; i < n; i++) {
                            sub+="<div class='col-lg-4 col-md-4'> <div class='form-group'><label for='"+subjects[i]+"' class='sr-only'>'"+subjects[i]+"'</label><select id='c"+i+"' class='custom-select input-form' required>" + 
                                    
                                res + "</select></div></div>";
                        }
            			fac_stu_3.html(sub);
            		}
            	});
            });  
        }
    });

// ---------------- Form Submition ------------- //
$('form[id="reg-form"]').submit(function (e) {
    e.preventDefault();
    f_name_arr = new String(fname.val()).split();
    l_name_arr = new String(lname.val()).split();
    if(f_name_arr.length > 1 || l_name_arr > 1){
        alert('please enter only one name without space');
    }
    else if(!name_reg.test(fname.val())){
        fname.val("");
        fname.attr({"placeholder":"Enter Correct Name"});
    }
    else if(lname.val() != "" &&  !name_reg.test(lname.val())){
        lname.val("");
        lname.attr("placeholder","Enter Correct name");
    }
    else if(!mob_reg.test(mobile.val())){
        mobile.val("");
        mobile.attr("placeholder","enter correct mobile");
    }
    else if(!email_reg.test(email.val())){
        email.val("");
        email.attr("placeholder","enter correct email");
    }
    else{
        fac_stu_cd=$('#fac-stu-cd').val();
        fac_stu_ss=$('#fac-stu-ss').val();
        var i=0;
        data="prof="+ proffesion +"&fname="+ fname.val() +"&lname="+ lname.val() +"&mobile="+ mobile.val() +"&email="+ email.val() +"&cord="+ fac_stu_cd +"&sos="+ fac_stu_ss +"&";
        if(proffesion == "f"){  
            
            for(i=0 ; i < parseInt(fac_stu_ss)-1 ; i++){
               if($('#c'+i).val() == $('#c'+(i+1)).val()){
                   alert('same');
                   return false;
               }
               data += 'c'+i+"="+$('#c'+i).val()+"&";
            }
            data += 'c'+i+"="+$('#c'+i).val();
        }
        else if(proffesion == "s"){
            rollno=$("#rollno");
            if(rollno_reg.test(rollno)){
                rollno.val("");
                rollno.attr({"placeholder" : "Enter the correct roll no"});
            }
            sem=$("#semester").val();
            section=$("#section").val();
            data+="rollno="+rollno.val()+"&course="+fac_stu_cd+"&branch="+fac_stu_ss+"&sem="+sem+"&section="+section;
        } 
        $.ajax({
            url:'../Register',
            method:'get',
            data:data,
            success:function(res){
                if(res == -1){
                    rollno.val("");
                    rollno.attr({"placeholder":"Already Exists "});
                   } 
                   else if(res == -2){
                     email.val("");
                     email.attr({"placeholder" : "Email already exists"});
                   }
                   else if(res == -3){
                     mobile.val("");
                     mobile.attr({"placeholder" : "Mobile already exists"});
                   }
                   else if(res == 1){
                	 alert("OTP send to email ID.please check");
                     window.location.href='otp.html';
                   }else{
                	  alert('Error! occured');
                	  location.reload(true);
                   }
            },
        });
    }
});
});