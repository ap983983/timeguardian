$(document).ready(function(){ 
    var profession = $('#profession');
    var username = $('#username');
    var password = $('#password');
    
    $('form[id="login-form"]').submit(function(e){
        e.preventDefault();
        $('.login').attr({disabled:true,tabindex:-1});
        var pro = profession.val();
        var location = (pro == 's')?'student' : (pro == 'f')? 'faculty':'hod';
        login_info = "prof="+ pro +"&username="+username.val()+"&password="+password.val();
        $.ajax({
        url:'../Login',
        data:login_info,
        method:'post',
        success:function(res){
            if(res == 1){
                window.location.href= "../" + location;
            }else if(res == -1){
            	$('.perr').text('');
                $('.perr').html('Invaild password');
            }else if(res == -2){
            	$('.uerr').html('Invaild Username');
            	$('.perr').html('Invaild password');
            }else{
                alert('Inactive User.Please contact Admin for verification');
            }
            $('.login').attr({disabled:false});
        },
        });
    });
});