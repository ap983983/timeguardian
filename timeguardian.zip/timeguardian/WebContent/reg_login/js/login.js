$(document).ready(function(){ 
    var profession = $('#profession');
    var username = $('#username');
    var password = $('#password');
    $('.alert').hide();
    profession.change(function(){
        var pro = profession.val();
        password.val('');
        if(pro == 's'){
            username.val('');
            username.attr({
                placeholder:'Your rollno/email*'
            });
        }else{
            username.val('');
            username.attr({
                placeholder:'Your ID/email*'
            });   
        }
    });
    $('form[id="login-form"]').submit(function(e){
        e.preventDefault();
        var pro = profession.val();
        var location = (pro == 's')?'student' : (pro == 'f')? 'faculty':'hod';
        login_info = "prof="+ pro +"&username="+username.val()+"&password="+password.val();
        $.ajax({
        url:'../Login',
        data:login_info,
        method:'post',
        success:function(res){
            if(res == 1){
                window.location.href= "../" + location;
            }else if(res == -1){
                $('.alert').show('slow',function(){
                	$('.errormsg').text('Invalid password');
                });
            }else if(res == -2){
                $('.alert').show('slow',function(){
                    $('.errormsg').text('Invalid username/password');
                });
            }else{
                $('.alert').show(function(){
                	$('.errormsg').text('Inactive User.Please contact Admin for verification');
                });
            }
        },
        });
    });
});