/*----------------------------------
    [ CONTACT US FORM JS ]
-----------------------------------*/
$(document).ready(function(){
   var regex_name=/^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$/;
   var regex_email= /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
   var regex_mobile=/^(\+\d{1,3}[- ]?)?\d{10}$/;
   var query_msg, name,email,mobile;
  
   $("#name").blur(function(){
        name=$(this).val();
        if(!regex_name.test(name)){
            $(this).val('');
            $(this).attr({"placeholder":"Correct name"});
        }
   });
   $("#email").blur(function(){
        email=$(this).val();
        if(!regex_email.test(email)){
            $(this).val('');
            $(this).attr({"placeholder":"Correct email"});
        }
   });
   $("#mobile").blur(function(){
        mobile=$(this).val();
        if(!regex_mobile.test(mobile)){
            $(this).val('');
            $(this).attr({"placeholder":"Correct mobile"});
        }
   });
  $('#con_form').submit(function(e){
      e.preventDefault();
      query_msg=$("#query_msg").val();
      var words = query_msg.split(' ');
      d="name="+ name + "&email="+email +"&mobile="+mobile+"&msg="+query_msg;
      $.ajax({
       url:'Contactus',
       method:'get',
       data: d,
       success:function(res){
    	   console.log(res);
    	   if(res == 1)
    		   alert("successfully send");
    	   	   window.location.reload();
       }
    });
  });
});
/*------------------------------
    [ LOGIN FORM JS ]
------------------------------ */ 