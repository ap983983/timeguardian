var images=["17.jpg"];
$(document).ready(function(){
    for(var i=0;i<images.length;i++)
    {           
        $('.header').fadeOut(5000,function(){
            $(this).css({
                "background":"url('"+'images/'+images[i]+"')",
            })
        });
    }
});